<?php
if (password_verify("brukes123","$2y$10\$CQt/t.9AyzUZ7K7i7RB8JuTrZFT/rWAyM5bMt33BwrBW/DetDeexu")):
echo "true";
else:
echo "false";
endif;