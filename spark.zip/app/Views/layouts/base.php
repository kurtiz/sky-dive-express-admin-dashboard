   
        <!-- NOTE MAIN PAGE CONTENT -->
        <?= $this->renderSection('content');